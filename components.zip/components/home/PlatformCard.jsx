import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, Shield } from "lucide-react";
import { motion } from "framer-motion";

const platformConfig = {
  whatsapp: {
    name: "WhatsApp",
    color: "from-green-500 to-green-600",
    bgColor: "bg-green-50",
    borderColor: "border-green-200",
    textColor: "text-green-700"
  },
  instagram: {
    name: "Instagram", 
    color: "from-pink-500 via-purple-500 to-orange-500",
    bgColor: "bg-gradient-to-br from-pink-50 to-purple-50",
    borderColor: "border-purple-200",
    textColor: "text-purple-700"
  },
  facebook: {
    name: "Facebook",
    color: "from-blue-500 to-blue-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
    textColor: "text-blue-700"
  },
  twitter: {
    name: "X (Twitter)",
    color: "from-gray-800 to-black",
    bgColor: "bg-gray-50",
    borderColor: "border-gray-300",
    textColor: "text-gray-800"
  }
};

export default function PlatformCard({ platform, guideCount }) {
  const config = platformConfig[platform];

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -5 }}
      transition={{ duration: 0.2 }}
    >
      <Link to={createPageUrl("Guides") + "?platform=" + platform}>
        <Card className={`overflow-hidden border-2 ${config.borderColor} hover:shadow-xl transition-all duration-300 cursor-pointer h-full`}>
          <div className={`h-24 bg-gradient-to-r ${config.color} relative overflow-hidden`}>
            <div className="absolute inset-0 bg-white/10" />
            <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/10 rounded-full" />
            <div className="absolute -left-8 -bottom-8 w-32 h-32 bg-white/20 rounded-full" />
          </div>
          
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-2xl font-bold mb-1">{config.name}</h3>
                <p className="text-sm text-gray-500">{guideCount} privacy guides</p>
              </div>
              <div className={`p-3 rounded-full ${config.bgColor}`}>
                <Shield className={`w-6 h-6 ${config.textColor}`} />
              </div>
            </div>
            
            <div className="flex items-center text-sm font-medium group">
              <span className={config.textColor}>View Guides</span>
              <ArrowRight className={`w-4 h-4 ml-2 ${config.textColor} group-hover:translate-x-1 transition-transform`} />
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}