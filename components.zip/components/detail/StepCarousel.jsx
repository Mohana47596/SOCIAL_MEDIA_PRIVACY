import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function StepCarousel({ steps }) {
  const [currentStep, setCurrentStep] = useState(0);

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const step = steps[currentStep];

  return (
    <div className="space-y-6">
      {/* Progress Bar */}
      <div className="flex items-center gap-2">
        {steps.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentStep(index)}
            className={`h-2 flex-1 rounded-full transition-all duration-300 ${
              index === currentStep
                ? 'bg-indigo-600'
                : index < currentStep
                ? 'bg-green-500'
                : 'bg-gray-200'
            }`}
          />
        ))}
      </div>

      {/* Step Content */}
      <Card className="overflow-hidden border-2">
        <CardContent className="p-0">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              {/* Step Header */}
              <div className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white p-6">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium opacity-90">
                    Step {currentStep + 1} of {steps.length}
                  </span>
                  {currentStep === steps.length - 1 && (
                    <div className="flex items-center gap-1 bg-white/20 px-3 py-1 rounded-full">
                      <Check className="w-4 h-4" />
                      <span className="text-sm">Final Step</span>
                    </div>
                  )}
                </div>
                <h3 className="text-xl font-bold">{step.instruction}</h3>
              </div>

              {/* Step Image */}
              {step.image_url && (
                <div className="bg-gray-100 p-8 flex items-center justify-center min-h-[400px]">
                  <img
                    src={step.image_url}
                    alt={`Step ${currentStep + 1}`}
                    className="max-w-full max-h-[500px] object-contain rounded-lg shadow-lg"
                  />
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between gap-4">
        <Button
          variant="outline"
          size="lg"
          onClick={prevStep}
          disabled={currentStep === 0}
          className="flex-1"
        >
          <ChevronLeft className="w-5 h-5 mr-2" />
          Previous
        </Button>
        
        {currentStep === steps.length - 1 ? (
          <Button
            size="lg"
            className="flex-1 bg-green-600 hover:bg-green-700"
            onClick={() => window.history.back()}
          >
            <Check className="w-5 h-5 mr-2" />
            Complete
          </Button>
        ) : (
          <Button
            size="lg"
            onClick={nextStep}
            className="flex-1 bg-indigo-600 hover:bg-indigo-700"
          >
            Next
            <ChevronRight className="w-5 h-5 ml-2" />
          </Button>
        )}
      </div>
    </div>
  );
}