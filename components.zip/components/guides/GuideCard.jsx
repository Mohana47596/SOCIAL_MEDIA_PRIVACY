import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowRight, AlertCircle, AlertTriangle, Info } from "lucide-react";
import { motion } from "framer-motion";

const importanceConfig = {
  critical: {
    icon: AlertCircle,
    color: "bg-red-100 text-red-700 border-red-200",
    label: "Critical"
  },
  high: {
    icon: AlertTriangle,
    color: "bg-orange-100 text-orange-700 border-orange-200",
    label: "High Priority"
  },
  medium: {
    icon: Info,
    color: "bg-blue-100 text-blue-700 border-blue-200",
    label: "Important"
  }
};

export default function GuideCard({ guide, index }) {
  const importance = importanceConfig[guide.importance] || importanceConfig.medium;
  const ImportanceIcon = importance.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
    >
      <Link to={createPageUrl("GuideDetail") + "?id=" + guide.id}>
        <Card className="hover:shadow-lg transition-all duration-300 cursor-pointer border-2 hover:border-indigo-200 h-full">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between gap-3 mb-2">
              <CardTitle className="text-lg leading-snug">{guide.title}</CardTitle>
              <Badge variant="outline" className={`${importance.color} border flex-shrink-0`}>
                <ImportanceIcon className="w-3 h-3 mr-1" />
                {importance.label}
              </Badge>
            </div>
            <p className="text-sm text-gray-600 line-clamp-2">{guide.description}</p>
          </CardHeader>
          
          <CardContent>
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">{guide.steps?.length || 0} steps</span>
              <div className="flex items-center text-indigo-600 font-medium group">
                <span>View Guide</span>
                <ArrowRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          </CardContent>
        </Card>
      </Link>
    </motion.div>
  );
}