import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, AlertCircle, AlertTriangle, Info, Clock } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import StepCarousel from "../components/detail/StepCarousel";
import { Skeleton } from "@/components/ui/skeleton";

const importanceConfig = {
  critical: {
    icon: AlertCircle,
    color: "bg-red-100 text-red-700 border-red-200",
    label: "Critical Priority",
    description: "This setting is crucial for your privacy and security"
  },
  high: {
    icon: AlertTriangle,
    color: "bg-orange-100 text-orange-700 border-orange-200",
    label: "High Priority",
    description: "Important setting that should be configured soon"
  },
  medium: {
    icon: Info,
    color: "bg-blue-100 text-blue-700 border-blue-200",
    label: "Important",
    description: "Recommended setting to improve your privacy"
  }
};

const platformNames = {
  whatsapp: "WhatsApp",
  instagram: "Instagram",
  facebook: "Facebook",
  twitter: "X (Twitter)"
};

export default function GuideDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const guideId = urlParams.get('id');

  const { data: guides, isLoading } = useQuery({
    queryKey: ['guides'],
    queryFn: () => base44.entities.PrivacyGuide.list(),
    initialData: [],
  });

  const guide = guides.find(g => g.id === guideId);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Skeleton className="h-12 w-32 mb-8" />
          <Skeleton className="h-16 w-full mb-4" />
          <Skeleton className="h-8 w-3/4 mb-8" />
          <Skeleton className="h-96 w-full" />
        </div>
      </div>
    );
  }

  if (!guide) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Guide not found</h2>
          <Button onClick={() => navigate(createPageUrl("Home"))}>
            Return to Home
          </Button>
        </div>
      </div>
    );
  }

  const importance = importanceConfig[guide.importance] || importanceConfig.medium;
  const ImportanceIcon = importance.icon;
  const estimatedTime = Math.ceil(guide.steps.length * 0.5); // 30 seconds per step

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <Button
          variant="ghost"
          onClick={() => navigate(createPageUrl("Guides") + "?platform=" + guide.platform)}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to {platformNames[guide.platform]} Guides
        </Button>

        {/* Title Section */}
        <div className="bg-white rounded-2xl border-2 p-8 mb-8 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
            <div className="flex-1">
              <h1 className="text-3xl md:text-4xl font-bold mb-3">{guide.title}</h1>
              <p className="text-gray-600 text-lg">{guide.description}</p>
            </div>
            <Badge variant="outline" className={`${importance.color} border text-base px-4 py-2 flex-shrink-0`}>
              <ImportanceIcon className="w-4 h-4 mr-2" />
              {importance.label}
            </Badge>
          </div>

          <div className="flex flex-wrap gap-4 pt-4 border-t">
            <div className="flex items-center gap-2 text-gray-600">
              <Clock className="w-5 h-5" />
              <span className="font-medium">~{estimatedTime} minutes</span>
            </div>
            <div className="flex items-center gap-2 text-gray-600">
              <Info className="w-5 h-5" />
              <span className="font-medium">{guide.steps.length} steps</span>
            </div>
          </div>
        </div>

        {/* Importance Alert */}
        <div className={`${importance.color} border-2 rounded-xl p-4 mb-8 flex items-start gap-3`}>
          <ImportanceIcon className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <p className="font-medium">{importance.description}</p>
        </div>

        {/* Steps */}
        <StepCarousel steps={guide.steps} />
      </div>
    </div>
  );
}