import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import GuideCard from "../components/guides/GuideCard";
import SearchBar from "../components/guides/SearchBar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";

const platformNames = {
  whatsapp: "WhatsApp",
  instagram: "Instagram",
  facebook: "Facebook",
  twitter: "X (Twitter)"
};

const categories = {
  all: "All Guides",
  account_security: "Account Security",
  personal_info: "Personal Info",
  messaging: "Messaging",
  posts_sharing: "Posts & Sharing",
  discovery: "Discovery & Visibility"
};

export default function Guides() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const platform = urlParams.get('platform');
  
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const { data: guides, isLoading } = useQuery({
    queryKey: ['guides', platform],
    queryFn: () => base44.entities.PrivacyGuide.filter({ platform }),
    initialData: [],
  });

  const filteredGuides = useMemo(() => {
    return guides.filter(guide => {
      const matchesSearch = guide.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           guide.description?.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || guide.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [guides, searchQuery, selectedCategory]);

  const platformGradients = {
    whatsapp: "from-green-500 to-green-600",
    instagram: "from-pink-500 via-purple-500 to-orange-500",
    facebook: "from-blue-500 to-blue-600",
    twitter: "from-gray-800 to-black"
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className={`bg-gradient-to-r ${platformGradients[platform]} text-white rounded-3xl p-8 md:p-12 mb-8 relative overflow-hidden`}>
          <div className="absolute inset-0 bg-black/10" />
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32" />
          
          <div className="relative">
            <Button
              variant="ghost"
              onClick={() => navigate(createPageUrl("Home"))}
              className="mb-4 text-white hover:bg-white/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
            
            <h1 className="text-4xl md:text-5xl font-bold mb-3">
              {platformNames[platform]} Privacy Guides
            </h1>
            <p className="text-white/90 text-lg">
              {filteredGuides.length} guides to help protect your privacy
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            placeholder="Search privacy guides..."
          />
        </div>

        {/* Category Tabs */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-8">
          <TabsList className="w-full justify-start overflow-x-auto flex-nowrap">
            {Object.entries(categories).map(([key, label]) => (
              <TabsTrigger key={key} value={key} className="whitespace-nowrap">
                {label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Guides Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-48 rounded-xl" />
            ))}
          </div>
        ) : filteredGuides.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">No guides found matching your search</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGuides.map((guide, index) => (
              <GuideCard key={guide.id} guide={guide} index={index} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}