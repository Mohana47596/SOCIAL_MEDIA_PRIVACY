import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import HeroSection from "../components/home/HeroSection";
import PlatformCard from "../components/home/PlatformCard";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: guides, isLoading } = useQuery({
    queryKey: ['all-guides'],
    queryFn: () => base44.entities.PrivacyGuide.list(),
    initialData: [],
  });

  // Count guides per platform
  const platformCounts = guides.reduce((acc, guide) => {
    acc[guide.platform] = (acc[guide.platform] || 0) + 1;
    return acc;
  }, {});

  const platforms = ['whatsapp', 'instagram', 'facebook', 'twitter'];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 py-8 md:py-12">
        <HeroSection />

        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-2">Choose Your Platform</h2>
          <p className="text-gray-600">Select a social media platform to view privacy guides</p>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Skeleton key={i} className="h-64 rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {platforms.map((platform) => (
              <PlatformCard
                key={platform}
                platform={platform}
                guideCount={platformCounts[platform] || 0}
              />
            ))}
          </div>
        )}

        {/* Features Section */}
        <div className="mt-20 grid md:grid-cols-3 gap-8">
          {[
            {
              title: "Step-by-Step Guides",
              description: "Clear instructions with screenshots showing exactly where to tap and what to select",
              gradient: "from-blue-500 to-cyan-500"
            },
            {
              title: "Priority Ratings",
              description: "Know which privacy settings are critical, high priority, or important to configure",
              gradient: "from-purple-500 to-pink-500"
            },
            {
              title: "Always Updated",
              description: "Guides are regularly updated to match the latest app versions and features",
              gradient: "from-orange-500 to-red-500"
            }
          ].map((feature, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 border-2 border-gray-100 hover:border-gray-200 transition-colors">
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${feature.gradient} mb-4 flex items-center justify-center text-white font-bold text-xl`}>
                {index + 1}
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}